#include "sacredBird.h"
#include "uiDraw.h"

/*******************************************
* Draws a bird.. which is a circle 
*********************************************/
void SacredBird :: draw()
{
	drawSacredBird(getPoint(), 15);
}
