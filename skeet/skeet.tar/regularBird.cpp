#include "regularBird.h"
#include "uiDraw.h"



/************************************
* Draws a Regular bird AKA a circle 
*************************************/
void RegularBird :: draw()
{
	drawCircle(getPoint(), 15);
}


